"ChatGPT-derived context tags for empathetic dialogue speech synthesis" made by Yuki Saito (UTokyo) in 2023

[Paper]
- Y. Saito et al., "ChatGPT-EDSS: empathetic dialogue speech synthesis trained from ChatGPT-derived context word embeddings," Proc. INTERSPEECH, 2023.

[Related resource]
- Corpus: https://sython.org/Corpus/STUDIES/
- Speech synthesizer: https://github.com/Wataru-Nakata/FastSpeech2-JSUT

[Data format]
- Each txt file contains several lines of three context words: 1) intention I, 2) emotion E, and 3) speaking style S and reliability score R like "I&E&S&R".
- Some files may contain multiple "I&E&S&R" due to the overlapped annotation schema like "I1&E1&S1&R1,I2&E2&S2&R2".

[Example ... "ChatGPT_EDSS_annotation\Long_dialogue\LD01\ChatGPT/LD01-Dialogue-01.txt"]
祝福&喜び&喜んでいる&1
問いかけ&信頼&可愛い&5
報告&喜び&元気&5,祝福&喜び&生き生きした&5
祝福&喜び&喜んでいる&5,祝福&喜び&丁寧&4
疑問&驚き&穏やか&1,祝福&喜び&穏やか&1,疑問&驚き&穏やか&2
褒め言葉&喜び&知的&5,祝福&喜び&喜んでいる&5
感謝&喜び&誠実&5,報告&喜び&元気&5,報告&喜び&元気&5
問いかけ&信頼&可愛い&4,疑問&信頼&丁寧&5
感謝&喜び&穏やか&3,報告&期待&落ち着いた&3,報告&喜び&知的&4
同意&信頼&穏やか&5,同意&期待&穏やか&5
報告&喜び&生き生きした&5,報告&期待&知的&2,報告&喜び&爽やか&4
同意&期待&落ち着いた&5,同意&知的&落ち着いた&5
報告&喜び&生き生きした&5,報告&喜び&生き生きした&5,報告&喜び&生き生きした&5
助言&期待&丁寧&5,祝福&期待&穏やかな&5
疑問&驚き&穏やか&5,問いかけ&疑念&穏やかな&5
提案&期待&穏やかな&5
同意&期待&生き生きした&5
